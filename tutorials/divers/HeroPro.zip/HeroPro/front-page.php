<?php get_header(); ?>

<div id="home-container">

	<!--slideshow-->
	
	<div id="slider" class="nivoSlider">

			<?php query_posts( array ('post_type' => 'slides', 'showposts' => 20  ) ); ?>
			
<?php $count_posts = wp_count_posts('slides'); ?>
		<?php $published_posts = $count_posts->publish; ?>

<?php if($published_posts != 0) { ?>			

			<?php while (have_posts()) : the_post(); ?>
			 
			 <?php $image= get_post_meta(get_the_ID(), 'Thumbnails', true); ?>
			<?php $imageUrl= get_post_meta(get_the_ID(), 'slide_url', true); ?>
		
		                  <?php if($image != '') : ?>
         <img src="<?php echo $image; ?>" alt="<?php the_title(); ?>" <?php if(of_get_option('slider_box') != 'off'){ ?> title="<span class='info-title'> <?php the_title(); ?></span><p><?php the_content(); ?></p>
		 <span class='read-more-slide'> <?php if($imageUrl != '') {?><a href='<?php echo $imageUrl; ?>'><?php _e( 'Read More', 'Hero' ); ?></a><?php } ?></span>" <?php } ?> />
                    <?php endif; ?>
			
			
		<?php endwhile; wp_reset_query(); ?>
		
				<?php } else { ?>
		<img src="<?php echo get_template_directory_uri() . '/images/slide1.jpg' ?>" />
	<?php }	?>
		
		</div> <!--slideshow end-->

  </div><!--home container end-->

<div class="clear"></div>

<!--welcome-->
	<div class="welcome_container">
<hr />
		<div class="two_third welcome-box">
		
	<h1><?php if(of_get_option('welcome_text') != NULL){ echo of_get_option('welcome_text');} else echo "Write your welcome headline here. Have fun with the Hero theme." ?></h1></div>
	
<div class="one_third last"><?php if(of_get_option('welcome_button') != NULL){ ?> 
    <a class="button large" href="<?php if(of_get_option('welcome_button_link') != NULL){ echo of_get_option('welcome_button_link');} ?>"><?php echo of_get_option('welcome_button'); ?></a> 
    <?php } else { ?> <a class="button large" href="<?php if(of_get_option('welcome_button_link') != NULL){ echo of_get_option('welcome_button_link');} ?>"> <?php echo "Download Now!" ?></a> <?php } ?></div>	
	
<hr />
</div><!--welcome end--> 
<div class="clear"></div>	
				
		<!--boxes-->
		<div id="box_container">
				
		<?php for ($i = 1; $i <= 3; $i++) { ?>
		
		
				<div class="boxes one_third <?php if ($i == 3) {echo "last";} ?>">
						<div class="box-head">
								
	<a href="<?php echo of_get_option('box_link' . $i); ?>"><img src="<?php if(of_get_option('box_image' . $i) != NULL){ echo of_get_option('box_image' . $i);} else echo get_template_directory_uri() . '/images/box' .$i. '.png' ?>" alt="<?php echo of_get_option('box_head' . $i); ?>" /></a>

					
					</div> <!--box-head close-->
					
				<div class="title-box">						
						
				<div class="title-head"><?php if(of_get_option('box_head' . $i) != NULL){ echo of_get_option('box_head' . $i);} else echo "Box heading" ?></div></div>
					
					<div class="box-content">

				<?php if(of_get_option('box_text' . $i) != NULL){ echo of_get_option('box_text' . $i);} else echo "Nullam posuere felis a lacus tempor eget dignissim arcu adipiscing. Donec est est, rutrum vitae bibendum vel, suscipit non metus." ?>
					
					</div> <!--box-content close-->
					
					
		
		<span class="read-more"><a href="<?php echo of_get_option('box_link' . $i); ?>"><?php _e('Read More' , 'Hero'); ?></a></span>
				
				</div><!--boxes  end-->
				
		<?php } ?>
		
		</div><!--box-container end-->
			
			<div class="clear"></div>
		
		
</div>
<!--wrapper end-->

<?php get_footer(); ?>