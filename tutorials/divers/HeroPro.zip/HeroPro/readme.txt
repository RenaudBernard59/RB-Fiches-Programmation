=== Hero ===
Author: Manishg
Tags: black,translation-ready,threaded-comments,light,two-columns,theme-options,red
Requires at least: WP 3.0

== Description ==

A very neat and clean black and red business theme. The theme supports widgets. And features theme-options, threaded-comments and multi-level dropdown menu. A simple and neat typography.

== Support ==
Support forum at http://antthemes.com/forum/

== Installation ==

You can install the theme through the WordPress installer under Themes-Install themes by searching for it.
Alternatively you can download the file from here, unzip it and move the unzipped contents to the wp-content/themes folder
of your WordPress installation. You will then be able to activate the theme.

== Frequently Asked Questions ==

= How do I set up the featured slider on the homepage? =
The Hero theme uses CUSTOM POST TYPE. In the wordpress admin, on the left side you will see a "SLIDES" POST type. Please ADD your SLIDES here. Don't forget to upload your image in the extra option field given Slider image of exact size 963px x 350px. 

= How to setup Blog page =
Create a new page by going to pages - Add New. Then on right side, in page attributes - Template, select Blog as the page template. And publish the page.

= Where can I get support for the theme? =
Support is available at the http://antthemes.com/forum/.

= How to use menus =
For Menus: Use wordpress Menu system under Appearance tab. Also, make sure menu titles are not long as they might overlap.

== Credits ==
jQuery http://jquery.com/

Thanks for downloading the Hero theme.

